import '../cabecalho/cabecalho.css'

function Cabecalho() {

  return (
    <>
      <div id='cabecalho'>
        <ul>
          <li>Pedra, Papel e Tesoura</li>
        </ul>
      </div> 
    </>
  )
}

export default Cabecalho