import '../rodape/rodape.css'


function Rodape() {

  return (
    <>
        <footer>
            <div className='texto'>Bernardo Reis & Mateus Campos © 2023</div>
        </footer>
    </>
  )
}

export default Rodape