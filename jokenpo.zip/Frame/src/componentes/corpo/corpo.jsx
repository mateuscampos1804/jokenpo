import '../corpo/corpo.css';
import imgPedra from "/pedra.png";
import imgPapel from "/papel.png";
import imgTesoura from "/tesoura.png";
import branco from "/image.png";
import { useState } from 'react';

function Corpo() {
  const [vet] = useState([imgPedra, imgPapel, imgTesoura]);
  const [escolhaPc, setEscolhaPc] = useState(null);
  const [escolhaJogador, setEscolhaJogador] = useState(null);
  const [empates,setEmpates] = useState(0)
  const [vitoriasUsuario,setVitoriasUsuario] = useState(0)
  const [vitoriasPc,setVitoriasPc] = useState(0)
  let empate = 0;
  let vitoriaUsuario = 0;
  let vitoriaPc = 0;

  const ImagemPc = () => {
    const num = Math.floor(Math.random() * 3);
    setEscolhaPc(vet[num]);
  };

  const imgJogPedra = () => {
    setEscolhaJogador(imgPedra);
  };

  const imgJogPapel = () => {
    setEscolhaJogador(imgPapel);
  };

  const imgJogTesoura = () => {
    setEscolhaJogador(imgTesoura);
  };

  const Placar = () => {
    if (escolhaJogador == escolhaPc) {
      empate++;
      setEmpates(empate)
    } else if (
      (escolhaJogador == imgPapel && escolhaPc == imgPedra) ||
      (escolhaJogador == imgPedra && escolhaPc == imgTesoura) ||
      (escolhaJogador == imgTesoura && escolhaPc == imgPapel)
    ) {
      vitoriaUsuario++;
      setVitoriasUsuario(vitoriaUsuario)
    } else {
      vitoriaPc++;
      setVitoriasPc(vitoriaPc)
    }

    setEscolhaJogador(branco)
    setEscolhaPc(branco)

  };

  return (
    <>
      <div id="placar">
        <h2>Você {vitoriasUsuario} X {vitoriasPc} Robo</h2>
        <h3>Empates: {empates}</h3>
      </div>

      <div id="confronto">
        <img src={escolhaJogador} alt="Escolha do jogador" />
        <img src={escolhaPc} alt="Escolha do PC" />
      </div>

      <div>
        <button id="pedra" onClick={imgJogPedra}>
          <img id="btn2" src={imgPedra} alt="Pedra" />
        </button>
        <button id="papel" onClick={imgJogPapel}>
          <img id="btn2" src={imgPapel} alt="Papel" />
        </button>
        <button id="tesoura" onClick={imgJogTesoura}>
          <img id="btn2" src={imgTesoura} alt="Tesoura" />
        </button>
      </div>

      <button id="btn1" onClick={ImagemPc}>JOGAR</button>
      <button id="btn" onClick={Placar}>ATUALIZAR PLACAR</button>

    </>
  );
}

export default Corpo;