import { useState } from 'react'
import './App.css'
import Corpo from './componentes/corpo/corpo'
import Rodape from './componentes/rodape/rodape'
import Cabecalho from './componentes/cabecalho/cabecalho'

function App() {

  return (
    <>
        <Cabecalho />
        <Rodape />
        <Corpo />
    </>
  )
}

export default App
